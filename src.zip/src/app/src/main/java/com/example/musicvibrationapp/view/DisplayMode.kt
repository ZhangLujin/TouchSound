package com.example.musicvibrationapp.view

enum class DisplayMode {
    TOP_BOTTOM,
    SIDES
}
