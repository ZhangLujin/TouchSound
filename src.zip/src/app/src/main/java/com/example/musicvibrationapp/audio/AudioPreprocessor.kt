package com.example.musicvibrationapp.audio

class AudioPreprocessor {
    fun process(rawData: ByteArray): ByteArray {
        return rawData
    }
} 